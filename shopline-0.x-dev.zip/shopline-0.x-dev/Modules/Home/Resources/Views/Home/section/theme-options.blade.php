<div class="theme-option">
    <div class="back-to-top">
        <a id="back-to-top" href="#">
            <i data-feather="chevron-up" class="text-white"></i>
        </a>
    </div>
</div>
<div class="bg-overlay"></div>
<div class="bg-overlay"></div>

