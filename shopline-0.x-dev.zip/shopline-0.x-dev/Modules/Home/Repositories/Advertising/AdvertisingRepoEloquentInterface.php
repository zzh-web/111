<?php

namespace Modules\Home\Repositories\Advertising;

/**
 * @method mixed getAdvertisingsByLocation(string $location)
 */
interface AdvertisingRepoEloquentInterface
{
}
