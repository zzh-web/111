<?php

namespace Modules\Product\Services;

interface ProductServiceInterface
{
}
