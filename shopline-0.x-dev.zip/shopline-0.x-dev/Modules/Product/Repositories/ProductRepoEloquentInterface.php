<?php

namespace Modules\Product\Repositories;

interface ProductRepoEloquentInterface
{
}
