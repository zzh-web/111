<?php

namespace Modules\Advertising\Enums;

enum AdvertisingStatusEnum: string
{
    case STATUS_ACTIVE = 'active';
    case STATUS_INACTIVE = 'inactive';
}
