<?php

namespace Modules\Advertising\Services;

interface AdvertisingServiceInterface
{
}
