<?php

namespace Modules\Advertising\Repositories;

interface AdvertisingRepoEloquentInterface
{
}
