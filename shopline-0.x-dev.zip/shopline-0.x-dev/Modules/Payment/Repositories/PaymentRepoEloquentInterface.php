<?php

namespace Modules\Payment\Repositories;

/**
 * @method findByInvoiceId ($id)
 * @method changeStatus    ($id, string $status)
 */
interface PaymentRepoEloquentInterface
{
}
