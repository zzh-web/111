<?php

namespace Modules\Payment\Gateways;

class Gateway
{
}
