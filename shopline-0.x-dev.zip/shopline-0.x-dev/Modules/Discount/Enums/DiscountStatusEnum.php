<?php

namespace Modules\Discount\Enums;

enum DiscountStatusEnum: string
{
    case STATUS_ACTIVE = 'active';
    case STATUS_INACTIVE = 'iactive';
}
