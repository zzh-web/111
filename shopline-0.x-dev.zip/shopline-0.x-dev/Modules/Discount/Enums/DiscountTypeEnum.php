<?php

namespace Modules\Discount\Enums;

enum DiscountTypeEnum: string
{
    case TYPE_ALL = 'all';
    case TYPE_SPECIAL = 'special';
}
