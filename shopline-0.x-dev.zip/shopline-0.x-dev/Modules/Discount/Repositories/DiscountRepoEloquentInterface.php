<?php

namespace Modules\Discount\Repositories;

/**
 * @method getLatest
 * @method findById ($id)
 */
interface DiscountRepoEloquentInterface
{
}
