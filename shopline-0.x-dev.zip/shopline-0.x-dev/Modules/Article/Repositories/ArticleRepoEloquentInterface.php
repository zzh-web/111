<?php

namespace Modules\Article\Repositories;

interface ArticleRepoEloquentInterface
{
}
