<?php

namespace Modules\Article\Services;

interface ArticleServiceInterface
{
}
