<?php

namespace Modules\Category\Enums;

enum CategoryStatusEnum: string
{
    case STATUS_ACTIVE = 'active';
    case STATUS_INACTIVE = 'inactive';
}
