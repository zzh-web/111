<?php

namespace Modules\Category\Services;

interface CategoryServiceInterface
{
}
