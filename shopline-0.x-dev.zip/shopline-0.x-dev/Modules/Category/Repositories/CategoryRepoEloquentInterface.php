<?php

namespace Modules\Category\Repositories;

interface CategoryRepoEloquentInterface
{
}
