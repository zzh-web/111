<?php

return [
    /**
     * Set menu for panel.
     */
    'menus' => [
        'panel'            => [],
        'home'             => [],
        'users'            => [],
        'categories'       => [],
        'role-permissions' => [],
        'products'         => [],
        'articles'         => [],
        'sliders'          => [],
        'advertisings'     => [],
        'comments'         => [],
        'contacts'         => [],
        'abouts'           => [],
    ],
];
