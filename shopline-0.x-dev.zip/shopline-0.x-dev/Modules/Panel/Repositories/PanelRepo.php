<?php

namespace Modules\Panel\Repositories;

class PanelRepo
{
}
