<?php

namespace Modules\Panel\Models;

class Panel
{
}
