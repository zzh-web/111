<?php

namespace Modules\Slider\Repositories;

interface SliderRepoEloquentInterface
{
}
