<?php

namespace Modules\Slider\Enums;

enum SliderStatusEnum: string
{
    case STATUS_ACTIVE = 'active';
    case STATUS_INACTIVE = 'inactive';
}
