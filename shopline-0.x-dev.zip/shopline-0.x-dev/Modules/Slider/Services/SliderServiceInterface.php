<?php

namespace Modules\Slider\Services;

interface SliderServiceInterface
{
}
