<?php

namespace Modules\User\Repositories;

interface UserRepoEloquentInterface
{
}
