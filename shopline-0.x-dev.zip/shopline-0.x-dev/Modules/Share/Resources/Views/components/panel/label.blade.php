<label class="{{ $class }}" for="{{ $for }}">{{ $title }} @if ($nullable) (no required) @endif</label>
