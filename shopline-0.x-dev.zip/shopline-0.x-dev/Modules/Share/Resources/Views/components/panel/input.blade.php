<input class="{{ $class }} @error($name) is-invalid @enderror" type="{{ $type }}" id="{{ $id }}" name="{{ $name }}"
placeholder="{{ $placeholder }}" value="{{ $value }}" {{ $attributes }}>
