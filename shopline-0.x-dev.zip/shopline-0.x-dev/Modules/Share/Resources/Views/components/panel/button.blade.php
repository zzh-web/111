<button class="{{ $class }}" type="{{ $type }}" {{ $attributes }}>
    {{ $title }}
</button>
