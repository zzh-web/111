<input type="file" name="{{ $name }}" id="{{ $id }}" class="form-control @error($name) is-invalid @enderror" {{ $attributes }}>
