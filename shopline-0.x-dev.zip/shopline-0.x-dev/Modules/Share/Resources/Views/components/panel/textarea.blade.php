<textarea class="{{ $class }} @error($name) is-invalid @enderror" id="{{ $id }}" rows="{{ $rows }}" name="{{ $name }}"
placeholder="{{ $placeholder }}" {{ $attributes }}>{{ $value }}</textarea>
