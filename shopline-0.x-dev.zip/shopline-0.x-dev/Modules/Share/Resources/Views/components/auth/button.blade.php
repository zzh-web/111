<button class="btn btn-animation w-100 justify-content-center" type="{{ $type }}">
    {{ $title }}
</button>
