<input class="form-control @error($name) is-invalid @enderror" type="{{ $type }}" name="{{ $name }}" placeholder="{{ $placeholder }}"
value="{{ $value }}" {{ $attributes }}>
