<p>
    Password must have a capital & lower letters with number & special character(Milwad123!).
</p>
