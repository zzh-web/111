<?php

return [
    'phone'       => '111 - 111',
    'email'       => 'shopline@gmail.com',
    'address'     => 'Iran, Tehran',
    'description' => "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.",

    /*
     * These factories is used when you run `db:seed` command, for set new factory you can go to related service provider
     * and set, ex:
     *
     * config()->set('shareConfig.factories.{name}', [
     *     'model'  => User::class,
     *     'count'  => 1,
     * ]);
     */
    'factories' => [],
];
