<div class="col-xxl-6 col-xl-5 col-lg-6 d-lg-block d-none ms-auto">
    <div class="image-contain">
        <img src="{{ $image }}" class="img-fluid" alt="log image">
    </div>
</div>
