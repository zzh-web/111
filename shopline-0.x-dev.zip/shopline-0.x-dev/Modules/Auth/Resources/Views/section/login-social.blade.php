<div class="log-in-button">
    <ul>{{-- TODO --}}
        <li>
            <a href="https://www.google.com/" class="btn google-button w-100">
                <img src="{{ asset('home/images/inner-page/google.png') }}" class="blur-up lazyload"
                alt="google"> Log In with Google
            </a>
        </li>
        <li>
            <a href="https://www.facebook.com/" class="btn google-button w-100">
                <img src="{{ asset('home/images/inner-page/facebook.png') }}" class="blur-up lazyload"
                alt="facebook"> Log In with Facebook
            </a>
        </li>
    </ul>
</div>
