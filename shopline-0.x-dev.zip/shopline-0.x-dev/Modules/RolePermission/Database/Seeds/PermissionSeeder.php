<?php

namespace Modules\RolePermission\Database\Seeds;

class PermissionSeeder
{
}
