<?php

namespace Modules\RolePermission\Repositories;

interface RolePermissionRepoEloquentInterface
{
}
