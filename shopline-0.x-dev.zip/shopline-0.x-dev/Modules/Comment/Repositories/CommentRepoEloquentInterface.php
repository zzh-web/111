<?php

namespace Modules\Comment\Repositories;

/**
 * @method getLatest
 * @method findById($id)
 */
interface CommentRepoEloquentInterface
{
}
