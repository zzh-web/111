<?php

namespace Modules\Contact\Services;

interface ContactServiceInterface
{
}
