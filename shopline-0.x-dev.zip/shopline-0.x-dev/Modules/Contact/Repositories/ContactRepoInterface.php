<?php

namespace Modules\Contact\Repositories;

interface ContactRepoInterface
{
}
