<?php

return [
    'tables' => [
        'name' => 'attributes',
    ],
];
