<?php

return [
    'module_namespace' => 'Modules',
];
